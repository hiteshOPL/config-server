package com.eazybytes.cards;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CardsApplicationTests {

	@Test
	void contextLoads() {
	}

}
