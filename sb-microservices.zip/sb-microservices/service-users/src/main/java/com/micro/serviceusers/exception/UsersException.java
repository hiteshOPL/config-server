package com.micro.serviceusers.exception;

public class UsersException extends RuntimeException {
    public UsersException(String exMessage, Exception exception) {
        super(exMessage, exception);
    }

    public UsersException(String exMessage) {
        super(exMessage);
    }
}
