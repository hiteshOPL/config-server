package com.micro.serviceusers.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_EMPTY)
public class CommonResponse implements Serializable {
	private String message;
	private Object data;
	private Integer status;
	private String debugMsg;

	public CommonResponse(String message) {
		this.message = message;
	}

	public CommonResponse(String message, Integer status) {
		this.message = message;
		this.status = status;
	}

	public CommonResponse(String message, Integer status, Object data) {
		this.message = message;
		this.status = status;
		this.data = data;
	}

	public CommonResponse(Integer status, String message, Throwable ex) {
		this.status = status;
		this.message = message;
		this.debugMsg = ex.getMessage();
	}

}
